import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  CheckCircleIcon,
  XCircleIcon,
  AlertTriangleIcon,
  HomeIcon,
} from "lucide-react";

const PaymentStatus = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [paymentResponse, setPaymentResponse] = useState(null);
  const [status, setStatus] = useState(null);

  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);

    const statusParam = queryParams.get("status");
    if (statusParam) setStatus(statusParam);

    const responseParam = queryParams.get("response");
    if (responseParam) {
      try {
        const decodedResponse = decodeURIComponent(responseParam);
        const parsedResponse = JSON.parse(decodedResponse);
        setPaymentResponse(parsedResponse);
      } catch (error) {
        console.error("Error parsing payment response:", error);
      }
    }
  }, [location]);

  if (!paymentResponse && status !== "PaymentCancelled!")
    return (
      <p className="text-center mt-10 text-gray-600">Processing payment...</p>
    );

  const isSuccess = paymentResponse?.order_status === "Success";
  const isCancelled = status === "PaymentCancelled!";

  const renderSection = (title, fields) => (
    <div className="bg-white rounded-2xl shadow-sm border p-5 mb-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-3 border-b pb-2">
        {title}
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-6 text-sm">
        {fields.map(([label, key]) => (
          <div key={key} className="flex justify-between">
            <span className="font-medium text-gray-500">{label}</span>
            <span className="text-gray-900 font-semibold">
              {paymentResponse?.[key] || "-"}
            </span>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto mt-10 px-4">
      {/* Status Card */}
      <div
        className={`rounded-2xl shadow-md border p-6 text-center transition-all ${
          isSuccess
            ? "bg-green-50 border-green-400"
            : isCancelled
            ? "bg-yellow-50 border-yellow-400"
            : "bg-red-50 border-red-400"
        }`}
      >
        <div className="flex justify-center mb-3">
          {isSuccess && (
            <CheckCircleIcon className="w-14 h-14 text-green-500" />
          )}
          {isCancelled && (
            <AlertTriangleIcon className="w-14 h-14 text-yellow-500" />
          )}
          {!isSuccess && !isCancelled && (
            <XCircleIcon className="w-14 h-14 text-red-500" />
          )}
        </div>
        <h2 className="text-2xl font-bold text-gray-900">
          {isSuccess
            ? "Payment Successful"
            : isCancelled
            ? "Payment Cancelled"
            : "Payment Failed"}
        </h2>
        <p className="mt-2 text-gray-600">
          {isSuccess
            ? "Your transaction has been completed successfully."
            : isCancelled
            ? "You cancelled the transaction."
            : paymentResponse?.failure_message ||
              "Something went wrong, please try again."}
        </p>

        {/* Action */}
        <button
          onClick={() => navigate("/")}
          className="mt-5 inline-flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white font-medium rounded-xl shadow hover:bg-blue-700 transition"
        >
          <HomeIcon className="w-5 h-5" />
          Go to Home
        </button>
      </div>

      {/* Details */}
      {paymentResponse && (
        <div className="mt-8">
          {renderSection("🧾 Order Details", [
            ["Order ID", "order_id"],
            ["Transaction ID", "tracking_id"],
            ["Date", "trans_date"],
            ["Status", "order_status"],
          ])}

          {renderSection("💳 Payment Details", [
            ["Amount", "amount"],
            ["Currency", "currency"],
            ["Mode", "payment_mode"],
            ["Card/Bank", "card_name"],
          ])}

          {renderSection("📍 Billing Details", [
            ["Name", "billing_name"],
            ["Email", "billing_email"],
            ["Phone", "billing_tel"],
            ["Address", "billing_address"],
            ["City", "billing_city"],
            ["State", "billing_state"],
            ["Zip", "billing_zip"],
            ["Country", "billing_country"],
          ])}

          {renderSection("🚚 Delivery Details", [
            ["Name", "delivery_name"],
            ["Phone", "delivery_tel"],
            ["Address", "delivery_address"],
            ["City", "delivery_city"],
            ["State", "delivery_state"],
            ["Zip", "delivery_zip"],
            ["Country", "delivery_country"],
          ])}
        </div>
      )}
    </div>
  );
};

export default PaymentStatus;
